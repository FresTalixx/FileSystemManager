#pragma once

#include "keyboardCommands.h"
int menuControl(const char* menu[], int menuSize, int startLineX, int startLineY);